<template>
  <b-row class="users">
    <b-col>
      <div class="m-3 text-center">
        <div>{{ $t("admin.posts-outsource") }}</div>
        <b-link to="/" target="_blank">{{ $t("admin.open-home") }}</b-link>
      </div>
    </b-col>
  </b-row>
</template>